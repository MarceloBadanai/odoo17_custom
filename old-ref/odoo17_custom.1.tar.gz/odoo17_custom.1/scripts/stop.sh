echo "Stop python process"

kill -9 $(pgrep -f python)

