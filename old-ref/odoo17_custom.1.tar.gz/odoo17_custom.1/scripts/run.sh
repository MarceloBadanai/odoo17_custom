cd /usr/lib/python3/dist-packages/odoo
odoo -c /workspaces/custom/odoo.conf
