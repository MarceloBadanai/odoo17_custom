# kill -9 $(pgrep -f python)

cd /usr/lib/python3/dist-packages/odoo
odoo -c /workspaces/odoo17_custom/odoo.conf -u demo
